import tkFileDialog
import Tkinter as tk
import ttk

root = tk.Tk()
root.minsize(600,400)
root.title("edl_table")

file_path_string = tkFileDialog.askopenfilename()

lines=[]
f = open(file_path_string, "r")
for x in f:
	lines.append(x)
f.close()
A=[]
B=[]

names=[""]
clipNum=0

for x in lines:
	y = x.split()
	if len(y) == 8 and not "*" in y[0]:
		B.append(y[4])
		B.append(y[5])
		B.append(y[6])
		B.append(y[7])
	elif len(y) > 0 and "*" in y[0] and "FROM" in y[1]:
		t=0
		name=""
		while t < len(y)-4:
			if t==0 or t==len(y)-1:
				name+=y[4+t]
			else:
				name+="_"
				name+=y[4+t]
			t+=1
		for i in names:
			if i==name:
				break;
			if i==names[len(names)-1]:
				names.append(name)
		B.append(name)
		A.append(B)
		B=[]
		clipNum+=1
mRow=0
data=[]
for x in A:
	data.append([])
	mCol=0
	for y in x:
		data[mRow].append(tk.StringVar())
		dataEntered = ttk.Entry(root, width = 15, textvariable = data[mRow][mCol], state = "readonly")
		dataEntered.grid(column = mCol, row = mRow+1)
		data[mRow][mCol].set(y)
		mCol += 1
	mRow += 1
nameBox=[]
nName=0
#for x in names:
#	if x != "":
#		nameBox.append(tk.StringVar())
#		nameBoxEntered = ttk.Entry(root, width = 15, textvariable = nameBox[nName], state = "readonly")
#		nameBoxEntered.grid(column = 2+nName, row = mRow+1)
#		nameBox[nName].set(x)
#		nName+=1
#
clipNumBox=tk.StringVar()
clipNumEntered = ttk.Entry(root, width = 15, textvariable = clipNumBox, state = "readonly")
clipNumEntered.grid(column = 0, row = 0)
clipNumBox.set(clipNum)
#print(A)
#print(names)
#print(clipNum)


root.mainloop()
